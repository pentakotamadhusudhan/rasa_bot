import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'models/bot_response_model.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Rasa Chat',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: ChatScreen(),
    );
  }
}

class ChatScreen extends StatefulWidget {
  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _controller = TextEditingController();
  List<BotResponseModel> _messages = [];

  Future<void> sendMessage(String message) async {
    final response = await http.post(
      Uri.parse('http://192.168.1.13:5005/webhooks/rest/webhook'),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"sender": "user", "message": message}),
    );
    print(response.body);
    if (response.statusCode == 200) {
      var res = jsonDecode(response.body);

      final List<dynamic> data = res;

      setState(() {
        for (var item in data) {
          _messages.add(BotResponseModel.fromJson(item));
        }
      });

      _controller.clear();
    } else {
      print("Failed to connect to Rasa");
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Chat with Rasa")),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final msg = _messages[index];
                return Align(
                  alignment: msg.recipientId != "user"
                      ? Alignment.centerRight
                      : Alignment.centerLeft,
                  child: Container(
                    margin: EdgeInsets.symmetric(vertical: 6, horizontal: 12),
                    padding: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: msg.recipientId != "user"
                          ? Colors.blue[100]
                          : Colors.grey[300],
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (msg.text != null)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 4),
                            child: Text(
                              msg.text!,
                              style: TextStyle(fontSize: 16),
                            ),
                          ),
                        if (msg.buttons != null && msg.buttons!.isNotEmpty)
                          Wrap(
                            spacing: 8,
                            runSpacing: 6,
                            children: msg.buttons!.map((button) {
                              return ElevatedButton(
                                onPressed: () {
                                  sendMessage(button.payload);
                                  BotResponseModel bot=BotResponseModel(recipientId: 'bot', text: button.title, buttons: []);// Send payload
                                  _messages.add(bot);
                                  setState(() {
                                    print(_messages);
                                  });
                                },
                                style: ElevatedButton.styleFrom(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 12, vertical: 6),
                                  backgroundColor: Colors.purple,
                                  foregroundColor: Colors.white,
                                  elevation: 2,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  textStyle: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 0.5,
                                  ),
                                ),
                                child: Text(button.title),
                              );
                            }).toList(),
                          ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(
                      hintText: "Type your message...",
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send),
                  onPressed: () {
                    if (_controller.text.isNotEmpty) {
                      sendMessage(_controller.text);
                      BotResponseModel bot=BotResponseModel(recipientId: 'bot', text:_controller.text, buttons: []);// Send payload
                      _messages.add(bot);
                      setState(() {
                        print(_messages);
                      });

                    }
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );

  }
}

class BotResponseModel {
  final String? recipientId;
  final String? text;
  final List<Button>? buttons;

  BotResponseModel({this.recipientId, this.text, this.buttons});

  factory BotResponseModel.fromJson(Map<String, dynamic> json) {
    List<Button>? buttonsList;

    if (json.containsKey('buttons') && json['buttons'] is List) {
      buttonsList = (json['buttons'] as List)
          .map((b) => Button.fromJson(b))
          .toList();
    }

    return BotResponseModel(
      recipientId: json['recipient_id'],
      text: json['text'],
      buttons: buttonsList,
    );
  }
}

class Button {
  final String title;
  final String payload;

  Button({required this.title, required this.payload});

  factory Button.fromJson(Map<String, dynamic> json) {
    return Button(
      title: json['title'] ?? '',
      payload: json['payload'] ?? '',
    );
  }
}
